void config(){
//	View.getDimension = &getDimension;
//	printf("teste");
}


